{-# LANGUAGE OverloadedStrings #-}

module Parser(

)
where
import Data.Void
import Data.Text(Text)
import qualified Data.Text as T

import Text.Megaparsec(Parsec, choice, some, MonadParsec, satisfy, oneOf, (<|>), between, optional, many)
import Text.Megaparsec.Char(space1, char)
import qualified Text.Megaparsec.Char.Lexer as L
import GHC.Unicode (isAlphaNum, isDigit, isHexDigit)
import Data.Maybe (fromMaybe)

type Parser = Parsec Void Text
type Lexer = Parsec Void Text


sc :: Parser ()
sc = L.space
  space1
  (L.skipLineComment "//|")
  (L.skipBlockComment "/|" "|\\")

lexeme :: Parser a -> Parser a
lexeme = L.lexeme sc

sym :: Text -> Token -> Lexer Token
sym s t = t <$ L.symbol sc s

kw :: Text -> Keyword -> Lexer Token
kw s k = TKW k <$ L.symbol sc s

digit :: Parser Char
digit = satisfy isDigit

hexDigit :: Parser Char
hexDigit = satisfy isHexDigit

digitOrUnderscore :: Parser Char
digitOrUnderscore = digit <|> char '_'

hexDigitOrUnderscore :: Parser Char
hexDigitOrUnderscore = hexDigit <|> char '_'

{-
HexFloat: '0' [xX] (HexIntDigitPart? '.' HexIntDigitPart HexExponentPart? | HexIntDigitPart HexExponentPart);
-}

hexFloatLiteral :: Parser String
hexFloatLiteral = do
  _ <- char '0'
  _ <- oneOf ("xX" :: String)
  choice [
      do
        a <- optional hexIntDigitPart
        _ <- char '.'
        b <- hexIntDigitPart
        e <- optional hexExponentPart
        pure $ fromMaybe "" a <> "." <> b <> fromMaybe "" e,
      do
        a <- hexIntDigitPart
        e <- hexExponentPart
        pure $ a <> e
    ]

floatLiteral :: Parser String
floatLiteral = do
  a <- intDigitPart
  _ <- char '.'
  b <- intDigitPart
  e <- optional exponentPart
  pure $ a <> "." <> b <> fromMaybe "" e

hexIntLiteral :: Parser String
hexIntLiteral = char '0' *> oneOf ['x', 'X'] *> hexIntDigitPart

intLiteral :: Parser String
intLiteral = intDigitPart

intDigitPart :: Parser String
intDigitPart = do
  prefix <- optional $ some digit <> many digitOrUnderscore
  suffix <- some digit
  pure $ fromMaybe "" prefix <> suffix

hexIntDigitPart :: Parser String
hexIntDigitPart = do
  prefix <- optional $ some hexDigit <> many hexDigitOrUnderscore
  suffix <- some hexDigit
  pure $ fromMaybe "" prefix <> suffix

exponentPart :: Parser String
exponentPart = do
  e <- oneOf ['e', 'E']
  s <- optional $ oneOf ['+', '-']
  ds <- some digit
  pure $ e : maybe "" pure s <> ds

hexExponentPart :: Parser String
hexExponentPart = do
  p <- oneOf ['p','P']
  s <- optional $ oneOf ['+', '-']
  ds <- some digit
  pure $ p : maybe "" pure s <> ds

normalChar :: Parser Char
normalChar = satisfy (\c -> isAlphaNum c || elem c ("_+/%|&^~<=>.*!?-" :: String))

nameText :: Lexer Text
nameText = T.pack <$> some normalChar

name :: Lexer Token
name = TName <$> nameText

tvar :: Lexer Token
tvar = TTVar <$> (char '`' *> nameText)

infixName :: Lexer Token
infixName = TInfixName <$> between (char '`') (char '`') nameText

token :: Lexer Token
token = choice [
    infixName,
    tvar,
    sym "$" TDollar,
    sym "@" TAt,
    sym "`" TBackTick,
    sym "#[" TSharpSquareL, sym "[" TSquareL, sym "]" TSquareR,
    sym "#{" TSharpBraceL,  sym "{" TBraceL,  sym "}" TBraceR,
    sym "(" TParenL,        sym ")" TParenR,
    sym ":=" TRebind,
    sym ":" TColon,
    sym "," TComma,
    sym "=" TAssign,
    sym "|" TPipe,
    kw "effect" KWEffect,
    kw "else" KWElse,
    kw "end" KWEnd,
    choice $ map (`kw` KWFalse) ["false", "⊥"],
    choice $ map (`kw` KWForall) ["forall", "∀"],
    kw "funct" KWFunct,
    kw "handle" KWHandle,
    kw "if" KWIf,
    choice $ map (`kw` KWIn) ["in", "∈"],
    kw "imm" KWImm,
    kw "let" KWLet,
    kw "match" KWMatch,
    kw "resume" KWResume,
    kw "then" KWThen,
    kw "to" KWTo,
    choice $ map (`kw` KWTrue) ["true", "⊤"],
    kw "type" KWType,
    kw "under" KWUnder,
    kw "val" KWVal,
    kw "var" KWVar,
    kw "with" KWWith,
    name
  ]

{-
Char_String: '\'' ('\\\\' | '\\\'' | Char)*? '\'';

LineComment: '//|' ~[\r\n]* -> channel(1);

OP_Underscore: '_';

OP_Function: '->';
OP_MatchArrow: '=>';
OP_HRP_Arrow: '==>';

//Sharp: '#';
//SHEBANG: Sharp '!' SingleLineInputCharacter* -> channel(HIDDEN);
SemiColon: ';';

fragment Char: ~['];
fragment SingleLineInputCharacter: ~[\r\n\u0085\u2028\u2029];

WS: [ \t\u000C\r\n]+ -> channel(1);
-}

data Token =
  TDollar
  | TAt
  | TBackTick
  | TColon
  | TComma
  | TSemi

  | TParenL       | TParenR
  | TBraceL       | TBraceR
  | TSquareL      | TSquareR
  | TSharpBraceL  | TSharpSquareL

  | TAssign
  | TRebind
  | TPipe

  | TArrow
  | TMatchArrow
  | THRPArrow

  | TKW Keyword        -- ключевые слова
  | TName Text
  | TInfixName Text
  | TTVar Text

  | TInt Integer
  | TFloat Scientific
  | TString Text
  | TBool Bool
  | TNil
  deriving (Show, Eq)

data Keyword =
  KWEffect
  | KWElse
  | KWEnd
  | KWFalse
  | KWForall
  | KWFunct
  | KWHandle
  | KWIf
  | KWIn
  | KWImm
  | KWLet
  | KWMatch
  | KWResume
  | KWThen
  | KWTo
  | KWTrue
  | KWType
  | KWUnder
  | KWVal
  | KWVar
  | KWWith
  deriving (Show, Eq)